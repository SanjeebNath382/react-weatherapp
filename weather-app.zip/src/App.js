import React, { Component, useState, useEffect } from 'react';
import Titles from './components/Titles'
import Form from './components/Form'
import Weather from './components/Weather'

import './App.css';
const API_KEY= '3052edc8e8a4356dfeaf545577e082e3';





 
   export default function App() {
    const [weather,setweather]=useState([])
    const [precLoc,setprecLoc]=useState([])
    const [ip,setip]= useState('14.139.61.203')
    const [query,setquery]=useState('New York')
    const [location,setlocation]=useState('New York')
    const [search,setsearch]= useState("New York")
    const publicIp= require('public-ip');
    //const geoIP= require('geoip-lite');
    const getIp = async()=>{
      const ipadd = await publicIp.v4();
      setip(ipadd);
      console.log(ipadd);
    }
    useEffect(()=>{
      getIp();
    },[])
    const s= `http://api.ipstack.com/${ip}?access_key=1c7ced0ccb96f93202340e6808b114dc`

    
      // const loc =  geoIP.lookup(ip);
      // //setprecLoc(loc.city);
      // console.log(loc)
      const getLoc = async()=>{
        const geoLoc = await fetch(s);
        const myLocation = await geoLoc.json()
         setprecLoc(myLocation)
        console.log(myLocation)
      }
      useEffect(()=>{
        getLoc();
      },[query])
      
    
    
      
    const getWeather = async()=>{

      const api_call =  await fetch(`http://api.weatherstack.com/current?access_key=${API_KEY}&query=${query}`);
      const data= await api_call.json();
     
       setweather(data.current);
       setlocation(data.location);
       
       
      

     
      }
      useEffect(()=>{
        getWeather();
      }, [query])
      const onSubHand= (e)=>{
        e.preventDefault();
        setquery(search)
        
       

      }
      const onChangeHand = (e)=>{
        setsearch(e.target.value)
      }
      const onLocChangeHand = (e)=>{
        e.preventDefault();
        //setsearch(precLoc)
        

      }
      

      


       
      
     return (
       
       <div  className="main" >
       <Titles />
       
       
     
      <form style={{marginLeft:"50%"}}>
        <input name='city' onChange={onChangeHand} value={search} className='search-bar'></input>
      <button name='Weather button' type='submit' className='SubmitButton' onClick={onSubHand}>Get Weather</button>
      <button name='Use Location button' type='submit' className='SubmitButton' onClick={onLocChangeHand}>Use Location</button>
      </form>
      {weather?<Weather time={weather.observation_time} temprature={weather.temperature} city={location.name} country={location.country} image={weather.weather_icons} description={weather.weather_descriptions} windspeed={weather.wind_speed} humidity={weather.humidity}/>:<h1>Loading......</h1>}
      
        
      </div>
      
         
       
     )
   }
   





