import React, { Component } from 'react';
import Weather from './Weather'
class Form extends Component {
    
    onClickHand = (e)=>{
        e.preventDefault();
        
        console.log(this.props.data.location.name)
        //{this.props.data.forEach(weatherData=>{<Weather city={weatherData.location.name} country={weatherData.location.country} time={weatherData.current.observation_time} temprature={weatherData.current.temperature}/>})}
        // {this.props.data.current.map(e=><Weather values={e}/>)}
        
        
        
    }
    
    render() {
        return (
            <form >
                <input name='city' placeholder='city'></input>
                <input name='country' placeholder='country'></input>
                <button onClick={this.onClickHand}>show weather</button>
               
              
               
                 
            </form>
        );
    }
}

export default Form;