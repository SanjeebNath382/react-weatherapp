import React, { Component } from 'react'

export default class Titles extends Component {
    render() {
        return (
            <div style={{marginLeft:"750px"}}>

            <h1>weather app</h1>
            <p style={{fontWeight:"bold"}}>find out conditions and more</p>
                
            </div>
        )
    }
}
