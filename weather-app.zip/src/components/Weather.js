import React, { Component } from 'react';
import '../App.css'

class weather extends Component {
    day = ()=>{ return(Date())
        
    }
    
    render() {
        return (
            <>
            <div style={{marginLeft:"50%"}} >
            {console.log(this.props.time)}
            {console.log(this.props.temprature)}
            {console.log(this.props.city)}
            <div className="box"><p style={{fontWeight:"bold"}}>Time of Measurement:</p> <p> {this.props.time}</p></div>
            <div className="box"><p style={{fontWeight:"bold"}}>Temprature:</p>

           
<p>{this.props.temprature}</p></div>
            <div className="box"> 
            <p style={{fontWeight:"bold"}}>City:</p>
            <p>{this.props.city}</p></div>
            <div className="box"> <p style={{fontWeight:"bold"}}>Country:</p>
            <p>{this.props.country}</p></div>
            <div className="box"> <p style={{fontWeight:"bold"}}>Description:</p>
            <p>{this.props.description}</p></div>
            <div className="box"><p style={{fontWeight:"bold"}}>Wind Speed:</p>
            <p>{this.props.windspeed}</p></div>
            <div className="box"><p style={{fontWeight:"bold"}}>Humidity:</p>
            <p>{this.props.humidity}</p></div>
            <img src={this.props.image} alt="loading"/>
            
            
            
           
           
            
           
            
            

            
            

                
            </div>
            </>
        );
    }
}

export default weather;